<?php $__env->startSection('title','Contact List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="m-t-0 header-title mb-4">V-Card Info</h4>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">

                            <?php if(\Session::has('message')): ?>
                                <div class="alert alert-success">
                                    <?php echo \Session::get('message'); ?>

                                </div>
                            <?php endif; ?>

                            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('card.update',$card->id)); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('Put'); ?>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">First name</label>
                                    <div class="col-10">
                                        <input value="<?php echo e($card->first_name); ?>" type="text" class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="first_name" required autocomplete="off">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Last name</label>
                                    <div class="col-10">
                                        <input value="<?php echo e($card->last_name); ?>"  type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="last_name" required autocomplete="off">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Email</label>
                                    <div class="col-10">
                                        <input value="<?php echo e($card->email); ?>"  type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" required autocomplete="off">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Designation</label>
                                    <div class="col-10">
                                        <input value="<?php echo e($card->designation); ?>" type="text" class="form-control <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="designation" required autocomplete="off">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Phone Number</label>
                                    <div class="col-10">
                                        <input value="<?php echo e($card->phone); ?>"  type="tel" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone" required autocomplete="off">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Your photo</label>
                                    <div class="col-10">
                                        <input type="file" class="form-control <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="photo" >
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Cover Photo</label>
                                    <div class="col-10">
                                        <input type="file" class="form-control <?php $__errorArgs = ['cover_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cover_photo" >
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Social Links</label>
                                    <div class="col-10" id="linkList">
                                        <?php if($card->link_1): ?>
                                            <?php $__currentLoopData = json_decode($card->link_1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="row socialLink">
                                                    <div class="col-9">
                                                        <div class="input-group mb-3">
                                                            <div class="input-group-prepend">
                                                                <select class="form-control" name="type[]" required>
                                                                    <option value="linkedin">linkedin</option>
                                                                    <option <?php if($key=='Vimeo'): ?> selected <?php endif; ?> value="Vimeo">Vimeo</option>
                                                                    <option <?php if($key=='facebook'): ?> selected <?php endif; ?> value="facebook">Favebook</option>
                                                                    <option <?php if($key=='Twiter'): ?> selected <?php endif; ?> value="Twiter">Twiter</option>
                                                                    <option <?php if($key=='Instagram'): ?> selected <?php endif; ?> value="Instagram">Instagram</option>
                                                                    <option <?php if($key=='Behance'): ?> selected <?php endif; ?> value="Behance">Behance</option>
                                                                    <option <?php if($key=='Youtube'): ?> selected <?php endif; ?> value="Youtube">Youtube</option>
                                                                    <option <?php if($key=='Skype'): ?> selected <?php endif; ?> value="Skype">Skype</option>
                                                                    <option <?php if($key=='WhatsApp'): ?> selected <?php endif; ?> value="WhatsApp">WhatsApp</option>
                                                                </select>
                                                            </div>
                                                            <input value="<?php echo e($link); ?>" type="text" class="form-control" placeholder="Website Address" name="link[]" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-3">
                                                        <button onclick="appendNewLink()" type="button" class="btn btn-primary"><i class="fas fa-plus"></i></button>
                                                        <button id="remove" type="button" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <div class="row socialLink">
                                                <div class="col-9">
                                                    <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                            <select class="form-control" name="type[]" required>
                                                                <option value="">select one</option>
                                                                <option value="linkedin">linkedin</option>
                                                                <option value="Vimeo">Vimeo</option>
                                                                <option value="facebook">Favebook</option>
                                                                <option value="Twiter">Twiter</option>
                                                                <option value="Instagram">Instagram</option>
                                                                <option value="Behance">Behance</option>
                                                                <option value="Youtube">Youtube</option>
                                                                <option value="Skype">Skype</option>
                                                                <option value="Whats App">Whats App</option>
                                                            </select>
                                                        </div>
                                                        <input type="text" class="form-control" placeholder="Website Address" name="link[]" required>
                                                    </div>
                                                </div>
                                                <div class="col-3">
                                                    <button onclick="appendNewLink()" type="button" class="btn btn-primary"><i class="fas fa-plus"></i></button>
                                                    <button id="remove" type="button" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-2 "></div>
                                    <div class="col-10">
                                        <button type="submit" class="btn btn-success">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
                <!-- end row -->

            </div> 
        </div><!-- end card -->
    </div><!-- end col -->

<div class="more" style="display: none;">
    <div class="row socialLink">
        <div class="col-9">
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <select class="form-control" name="type[]" required>
                        <option value="">select one</option>
                        <option value="linkedin">linkedin</option>
                        <option value="Vimeo">Vimeo</option>
                        <option value="facebook">Favebook</option>
                        <option value="Twiter">Twiter</option>
                        <option value="Instagram">Instagram</option>
                        <option value="Behance">Behance</option>
                        <option value="Youtube">Youtube</option>
                        <option value="Skype">Skype</option>
                        <option value="Whats App">Whats App</option>
                    </select>
                </div>
                <input type="text" class="form-control" placeholder="Website Address" name="link[]" required>
            </div>
        </div>
        <div class="col-3">
            <button onclick="appendNewLink()" type="button" class="btn btn-primary"><i class="fas fa-plus"></i></button>
            <button id="remove" type="button" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        function appendNewLink(){
            var l= $('.socialLink').length;
            if (l > 4 ) {
                alert('Opps !! you can add 4 links');
            }else{
                $('#linkList').append($('.more').html());
            }
            
        }
        $('body').delegate('#remove','click', function(){
            var l= $('.socialLink').length;
            if (l == 1) {
                alert('you can not remove Last Row');
            }else{
                $(this).parent().parent().remove();
            }
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bappy/www/html/v-card/resources/views/admin/card/show.blade.php ENDPATH**/ ?>