<li class="menu-title">Navigation</li>
<li>
    <a href="<?php echo e(route('card.show',auth()->user()->id)); ?>"  class="<?php echo e(Request::is('card*') ? 'active' : ''); ?>">
        <i class="ion-md-speedometer"></i>  Your V-Card
    </a>
</li>
<li>
    <a target="_blank" href="<?php echo e(route('card.username',auth()->user()->card->user_name)); ?>">
        <i class="ion ion-md-card"></i>  View Your Card
    </a>
</li>
<li>
    <a href="<?php echo e(route('profile')); ?>"  class="<?php echo e(Request::is('profile*') ? 'active' : ''); ?>">
        <i class="ion ion-ios-contact"></i>  Profile
    </a>
</li><?php /**PATH /home/bappy/www/html/v-card/resources/views/inc/user_nav.blade.php ENDPATH**/ ?>