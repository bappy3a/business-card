<?php $__env->startSection('title','Contact List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body table-responsive">
                    <div class="row">
                        <div class="col-6">
                            <h4 class="m-t-0 header-title mb-4"><b>Contact List</b></h4>
                        </div>
                        <div class="col-6">
                            <a href="<?php echo e(route('card.create')); ?>" class="btn btn-primary" style="margin-top: -9px;float: right;"> Add New</a>
                        </div>
                    </div>
                    

                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">

                        <thead>
                            <tr>
                                <th>QrCode</th>
                                <th>#Id</th>
                                <th>Name</th>
                                <th>Email Address</th>
                                <th>Mobile Number</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo QrCode::size(60)->generate(route('card.username',$item->user_name)); ?></td>
                                    <td><?php echo e($item->user_name); ?></td>
                                    <td><?php echo e($item->first_name . ' ' . $item->last_name); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td><?php echo e($item->phone); ?></td>
                                    <td><?php echo e($item->created_at->format('M/d/y')); ?></td>
                                    <td>
                                        <a target="_blank" href="<?php echo e(route('card.username',$item->user_name)); ?>" class="btn btn-primary btn-sm">View</a>
                                        <a onclick="return confirm('are you sure?')" href="<?php echo e(route('card.delete',$item)); ?>" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.datatables.net/1.11.2/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.2/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#datatables').DataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.2/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bappy/www/html/v-card/resources/views/admin/card/index.blade.php ENDPATH**/ ?>