<!DOCTYPE html>
<html class="no-js" lang="">
<head>
    <meta charset="utf-8" />
    <title><?php echo e($card->first_name); ?>  <?php echo e($card->last_name); ?></title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <meta property="og:title" content="" />
    <meta property="og:type" content="" />
    <meta property="og:url" content="" />
    <meta property="og:image" content="" />

    <link rel="manifest" href="site.webmanifest" />
    <link rel="apple-touch-icon" href="icon.png" />
    <!-- Place favicon.ico in the root directory -->

    <!-- -----cdn------ -->
     <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.css">
    <!-- -----cdn------ -->

    <link rel="stylesheet" href="<?php echo e(asset('website/css/normalize.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('website/css/main.css')); ?>" />

    <meta name="theme-color" content="#fafafa" />

</head>

<body>

    <section>
        <div class="wrapper">
            <div class="profile-card">
                <div class="profile-header">
                    <?php if($card->cover_photo): ?>
                        <img src="<?php echo e(asset($card->cover_photo)); ?>" alt="heder">
                    <?php else: ?>
                        <img src="<?php echo e(asset('website/img/heder.png')); ?>" alt="heder">
                    <?php endif; ?>
                    
                </div>
                <div class="qr">
                    <a href=""><?php echo QrCode::size(34)->generate(route('card.username',$card->user_name)); ?></a>
                </div>
                <div class="profile-body">
                    <div class="author-img">
                        <?php if($card->photo): ?>
                            <img src="<?php echo e(asset($card->photo)); ?>" alt="heder">
                        <?php else: ?>
                            <img src="<?php echo e(asset('website/img/heder.png')); ?>" alt="heder">
                        <?php endif; ?>
                    </div>
                    <div class="name"><?php echo e($card->first_name); ?>  <?php echo e($card->last_name); ?></div>
                    <div class="intro">
                        <p><?php echo e($card->phone); ?></p>
                    </div>
                    <div class="social-icon">
                        <?php if($card->link_1): ?>
                            <ul>
                                <?php $__currentLoopData = json_decode($card->link_1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php if($key == 'linkedin'): ?>
                                            <i class="fab fa-linkedin-in"></i>
                                        <?php elseif($key == 'Vimeo'): ?>
                                            <i class="fab fa-vimeo-v"></i>
                                        <?php elseif($key == 'facebook'): ?>
                                            <i class="fab fa-facebook"></i>
                                        <?php elseif($key == 'Twiter'): ?>
                                            <i class="fab fa-"></i>
                                        <?php elseif($key == 'Instagram'): ?>
                                            <i class="fab fa-instagram"></i>
                                        <?php elseif($key == 'Behance'): ?>
                                            <i class="fab fa-behance"></i>
                                        <?php elseif($key == 'Youtube'): ?>
                                            <i class="fab fa-youtube"></i>
                                        <?php elseif($key == 'Skype'): ?>
                                            <i class="fab fa-skype"></i>
                                        <?php elseif($key == 'WhatsApp'): ?>
                                            <i class="fab fa-whatsapp"></i>
                                        <?php endif; ?>
                                        <span>&nbsp;&nbsp;&nbsp;<?php echo e($link); ?></span>
                                    </li>
                                    <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        <?php endif; ?>

                    </div>
                    <div class="social-icon footer">
                        <ul>
                            <li>
                                <a href="tel:<?php echo e($card->phone); ?>">
                                    <i class="fas fa-phone-alt"></i>
                                </a>
                            </li>
                            <li>
                                <a href="mailto:<?php echo e($card->email); ?>">
                                    <i class="fas fa-envelope-open-text"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fas fa-share-alt"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fas fa-download"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- <div class="profile-body">
                    <span></span>
                </div> -->
                <div class="footer">
                    <span class="web_address">www.thelakhanigroup.com</span>
                    <span class="pby">Powered By <img src="<?php echo e(asset('website/img/pby.jpg')); ?>" alt=""></span>
                </div>
            </div>
        </div>  
    </section>




    <!-- Add your site or application content here -->

    <script src="<?php echo e(asset('website/js/vendor/modernizr-3.11.2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('website/js/plugins.js')); ?>"></script>
    <script src="<?php echo e(asset('website/js/main.js')); ?>"></script>

    <!-- Google Analytics: change UA-XXXXX-Y to be your site's ID. -->
    <script>
    window.ga = function () {
        ga.q.push(arguments);
    };
    ga.q = [];
    ga.l = +new Date();
    ga("create", "UA-XXXXX-Y", "auto");
    ga("set", "anonymizeIp", true);
    ga("set", "transport", "beacon");
    ga("send", "pageview");
    </script>
    <script src="https://www.google-analytics.com/analytics.js" async></script>
</body>
</html>
<?php /**PATH /home/bappy/www/html/v-card/resources/views/cardView.blade.php ENDPATH**/ ?>