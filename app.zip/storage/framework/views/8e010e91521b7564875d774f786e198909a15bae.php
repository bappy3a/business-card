<li class="menu-title">Navigation</li>
<li>
    <a href="<?php echo e(route('home')); ?>"  class="<?php echo e(Request::is('home') ? 'active' : ''); ?>">
        <i class="ion-md-speedometer"></i>  Dashboard
    </a>
</li>
<li>
    <a href="<?php echo e(route('card.index')); ?>"  class="<?php echo e(Request::is('card*')  ? 'active' : ''); ?>">
        <i class="ion ion-ios-contact"></i>  Contact Us
    </a>
</li><?php /**PATH /home/bappy/www/html/v-card/resources/views/inc/nav.blade.php ENDPATH**/ ?>